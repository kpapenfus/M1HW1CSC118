//kyrstine papenfus
//CSC118
//1/25/2020
//M1HW1
print("                            ><{{{*> AQUAMAN <*}}}><                               ")
print(" ")
print(" ")
var name:String
name = "Aquaman"
print("The movie I chose was \(name) ")
let date = 2018
let monies = 335.1
let world = 1.15
print(" ")
print("\(name) released in \(date)")
print(" ")
print(" ><{{{*>                                                                  <*}}}>< ")
print(" ")
print("\(name) made an amount of $\(monies) Million dollars in the U.S and Canada")
print(" ")
print("And made a grand total of $\(world) Billion dollars Worldwide")
print(" ")
print("----------------------------------------------------------------------------------")
print("           ><{{{*> ><{{{*> ><{{{*> ><{{{*> ><{{{*> ><{{{*> ><{{{*> ><{{{*>") 
print("----------------------------------------------------------------------------------")
print(" ")
print("                ><{{{*> Some qoutations from the movie <*}}}><                    ")
print(" ")
print("Arthur helps save russian salors from pirates and as he is leading them to freedom\n He says \"Hurry up, I'm missing happy hour for this.\"")
print(" ")
print(" ")
print("At the end of the fight scene between \(name) and the pirates, one of the pirate is hurt and trapped, as \(name) is leaving the pirates plead for help and \(name) replies with\n\"Ask the sea for mercy.\" ")
print(" ")
print(" ")
print("As the pirate is fixing new gear given to him by the Alantieans, Manta (pirate) claims\n\"I'm going to need a bigger helment.\"")
print(" ")
print(" ")
print("Aruthur having a drink with his father\n\"How is it that I can breathe underwater, but you can still drink me under the table?\"")
print(" ")
print("His father replied with, \n\"That's *my* superpower.\"")
print(" ")
print(" ")
print("----------------------------------------------------------------------------------")
print("           ><{{{*> ><{{{*> ><{{{*> ><{{{*> ><{{{*> ><{{{*> ><{{{*> ><{{{*>") 
print("----------------------------------------------------------------------------------")





